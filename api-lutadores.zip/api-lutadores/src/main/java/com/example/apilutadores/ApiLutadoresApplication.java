package com.example.apilutadores;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiLutadoresApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiLutadoresApplication.class, args);
	}

}
